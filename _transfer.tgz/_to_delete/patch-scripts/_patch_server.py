import sys, io

PATH = "netlify/functions/booking-core.mts"
src = io.open(PATH, encoding="utf-8").read()
orig = src

def sub(old, new, label):
    global src
    if src.count(old) != 1:
        print("FAIL(%s): found %d matches" % (label, src.count(old)))
        sys.exit(1)
    src = src.replace(old, new, 1)
    print("ok:", label)


# 1. Single-item read alongside readItems().
old1 = """    ORDER BY ci.week, ci.day, ci.start, ci.id
  `;
  return rows.map(rowToItem);
}
"""
new1 = """    ORDER BY ci.week, ci.day, ci.start, ci.id
  `;
  return rows.map(rowToItem);
}

// Same shape as readItems() but for a single booking. Used by paths that act on
// one item and have no reason to pull the whole calendar first.
async function readCalendarItemById(itemId) {
  const cleanId = cleanString(itemId, "", 140);
  if (!cleanId) return null;
  const rows = await db().sql`
    SELECT ci.*,
           (s.optix_booking_id IS NOT NULL AND s.optix_booking_id <> ''
            AND s.sync_status = 'synced') AS bay_booked,
           s.resource_id AS bay_resource_id
    FROM calendar_items ci
    LEFT JOIN optix_booking_sync s ON s.calendar_item_id = ci.id
    WHERE ci.id = ${cleanId}
    LIMIT 1
  `;
  return rows.length ? rowToItem(rows[0]) : null;
}
"""
sub(old1, new1, "readCalendarItemById")


# 2. Lean state read for the lesson-completion path.
old2 = """async function readAdminCalendarShellState() {"""
new2 = """// Marking one lesson complete needs the target booking plus the settings the
// permission check reads. It does not need people, notification history or the
// Google sync status, so this skips those three reads entirely and looks the
// booking up by id instead of scanning the whole calendar.
async function readLessonCompleteState(itemId) {
  const { settings: settingsMap, syncKey, updatedAt } = await readStateSettingsSnapshot();
  const account = coachAccountFromSettings(settingsMap);
  const item = await readCalendarItemById(itemId);
  return {
    syncKey,
    updatedAt,
    items: item ? [item] : [],
    services: servicesFromSettings(settingsMap),
    workspaceAccounts: workspaceAccountsFromSettings(settingsMap, account),
    coaches: coachProfilesFromSettings(settingsMap, account),
    currentUser: appUsersFromSettings(settingsMap, account)[0],
    locations: locationsFromSettings(settingsMap, account),
    availability: availabilityFromSettings(settingsMap),
    people: [],
    notifications: [],
    settings: adminSettingsFromSettings(settingsMap),
    brand: brandSettingsFromSettings(settingsMap, account),
    account,
  };
}

async function readAdminCalendarShellState() {"""
sub(old2, new2, "readLessonCompleteState")


# 3. Only read the full calendar state for the actions that actually need it.
old3 = """      const body = await parseBody(req);
      const current = await readCalendarState();
      const action = cleanString(body?.action, "", 120);
      if (action === "complete_lesson") {
        const startAt = Date.now();
        const requestContext = await resolveBackendRequestContext(req, current);
        const itemId = cleanString(body?.itemId, "", 140);
"""
new3 = """      const body = await parseBody(req);
      const action = cleanString(body?.action, "", 120);
      if (action === "complete_lesson") {
        const startAt = Date.now();
        const itemId = cleanString(body?.itemId, "", 140);
        const current = await readLessonCompleteState(itemId);
        const requestContext = await resolveBackendRequestContext(req, current);
"""
sub(old3, new3, "put-handler-lean-read")


# The completion branch always returns, so the full read can move below it.
old4 = """      if (action === "upsert_item") {
        const startAt = Date.now();
        const requestContext = await resolveBackendRequestContext(req, current);
        const candidateItem = { ...(body?.item || {}), accountId: requestContext.accountId };
"""
new4 = """      const current = await readCalendarState();
      if (action === "upsert_item") {
        const startAt = Date.now();
        const requestContext = await resolveBackendRequestContext(req, current);
        const candidateItem = { ...(body?.item || {}), accountId: requestContext.accountId };
"""
sub(old4, new4, "put-handler-full-read")

io.open(PATH, "w", encoding="utf-8").write(src)
print("written, delta bytes:", len(src) - len(orig))
