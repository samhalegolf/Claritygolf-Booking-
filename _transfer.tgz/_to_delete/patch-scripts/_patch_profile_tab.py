import sys, io

def load(p):
    return io.open(p, encoding="utf-8").read()

def save(p, t):
    io.open(p, "w", encoding="utf-8").write(t)

def sub(text, old, new, label):
    if text.count(old) != 1:
        print("FAIL(%s): found %d matches" % (label, text.count(old)))
        sys.exit(1)
    print("ok:", label)
    return text.replace(old, new, 1)


# ============================================================ VideoWorkspace
P = "src/modules/video-analysis/VideoWorkspace.tsx"
s = load(P)

s = sub(
    s,
    """  /** Return false to tell the note panel the save failed and keep the text. */
  onSaveNote?: (text: string) => boolean | void | Promise<boolean | void>;
}""",
    """  /** Return false to tell the note panel the save failed and keep the text. */
  onSaveNote?: (text: string) => boolean | void | Promise<boolean | void>;
  /** Open the camera recorder as soon as the workspace mounts. */
  autoStartLiveRecording?: boolean;
}""",
    "ws-props",
)

s = sub(
    s,
    """  onSaveNote,
}: VideoWorkspaceProps) {""",
    """  onSaveNote,
  autoStartLiveRecording,
}: VideoWorkspaceProps) {""",
    "ws-destructure",
)

s = sub(
    s,
    """  const startLiveRecording = useCallback(() => {""",
    """  // Entering straight from the Profile tab's record button. The ref keeps this
  // to a single shot, so closing the recorder does not immediately reopen it.
  const autoRecordStartedRef = useRef(false);
  useEffect(() => {
    if (!autoStartLiveRecording || autoRecordStartedRef.current) return;
    if (workspaceHasVideo) return;
    autoRecordStartedRef.current = true;
    void openLiveRecording("left");
  }, [autoStartLiveRecording, openLiveRecording, workspaceHasVideo]);

  const startLiveRecording = useCallback(() => {""",
    "ws-auto-record",
)
save(P, s)


# =========================================================== VideoAnalysisPage
P = "src/modules/video-analysis/VideoAnalysisPage.tsx"
s = load(P)
s = sub(
    s,
    """  onSaveNote?: (text: string) => boolean | void | Promise<boolean | void>;
}""",
    """  onSaveNote?: (text: string) => boolean | void | Promise<boolean | void>;
  autoStartLiveRecording?: boolean;
}""",
    "page-props",
)
save(P, s)


# ==================================================================== App.tsx
P = "src/App.tsx"
s = load(P)

s = sub(
    s,
    """  const [videoContext, setVideoContext] = useState<{ playerId: string; playerName: string; savedVideoId?: string } | null>(null);""",
    """  const [videoContext, setVideoContext] = useState<{
    playerId: string;
    playerName: string;
    savedVideoId?: string;
    startRecording?: boolean;
  } | null>(null);""",
    "video-context-state",
)

s = sub(
    s,
    """  function openVideoAnalysisForClient(client: { id: string; name: string; savedVideoId?: string }) {
    setVideoContext({ playerId: client.id, playerName: client.name, savedVideoId: client.savedVideoId });
    setActiveView("video");
    closeClientModal();
    setQuickCreate(null);
    closeCalendarDetails();
  }""",
    """  function openVideoAnalysisForClient(client: {
    id: string;
    name: string;
    savedVideoId?: string;
    startRecording?: boolean;
  }) {
    setVideoContext({
      playerId: client.id,
      playerName: client.name,
      savedVideoId: client.savedVideoId,
      startRecording: client.startRecording,
    });
    setActiveView("video");
    closeClientModal();
    setQuickCreate(null);
    closeCalendarDetails();
  }

  // Straight from a booking into a fresh camera recording for that player.
  function startVideoRecordingForClient(client: Pick<Person, "id" | "name" | "email" | "phone">) {
    openVideoAnalysisForClient({
      id: preferredVideoPlayerId(client, videoPlayerIds),
      name: client.name,
      startRecording: true,
    });
  }

  function openPlayerProfileVideos(client: Pick<Person, "id" | "name">) {
    selectPlayerProfileTool(client, "videos");
    setActiveView("players");
    closeClientModal();
    setQuickCreate(null);
    closeCalendarDetails();
  }""",
    "app-handlers",
)

s = sub(
    s,
    """                savedVideoId={videoContext?.savedVideoId}""",
    """                savedVideoId={videoContext?.savedVideoId}
                autoStartLiveRecording={videoContext?.startRecording}""",
    "app-pass-autorecord",
)

# The Profile tab sits directly above Booking records and follows the same
# collapsible pattern.
s = sub(
    s,
    """      {selected.kind === "appointment" && (
        <details className="booking-records-tab">
          <summary className="booking-records-summary">
            <Mail size={16} />
            <span>Booking records</span>""",
    """      {selected.kind === "appointment" && selectedPerson && (
        <details className="booking-records-tab booking-profile-tab">
          <summary className="booking-records-summary">
            <User size={16} />
            <span>Profile</span>
            <em>{selectedPerson.name}</em>
          </summary>
          <div className="booking-records-body">
            <div className="booking-profile-actions">
              <button
                className="outline-button"
                onClick={() => startVideoRecordingForClient(selectedPerson)}
                type="button"
              >
                <Video size={16} />
                New recording
              </button>
              <button
                className="outline-button"
                onClick={() => openPlayerProfileVideos(selectedPerson)}
                type="button"
              >
                <User size={16} />
                Player profile
              </button>
            </div>
            <Suspense fallback={<div className="module-loading">Loading notes…</div>}>
              <ClarityVoiceTextPanel
                fieldLabel="Lesson note"
                placeholder="Type or dictate a note for this lesson."
                onCommit={(text) => saveLessonNoteForClient(selectedPerson, text, "voice")}
              />
            </Suspense>
          </div>
        </details>
      )}

      {selected.kind === "appointment" && (
        <details className="booking-records-tab">
          <summary className="booking-records-summary">
            <Mail size={16} />
            <span>Booking records</span>""",
    "profile-tab",
)
save(P, s)


# ================================================================= stylesheet
P = "src/styles.css"
s = load(P)
s = sub(
    s,
    """.booking-resend-button {
  justify-self: start;
}""",
    """.booking-resend-button {
  justify-self: start;
}

.booking-profile-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

/* The note panel is shared with the player profile, where it sits on the same
   panel background. Keep it flush inside the tab body. */
.booking-profile-tab .clarityVoicePanel {
  max-width: 100%;
}

.booking-profile-tab .clarityVoiceTextOutput textarea {
  min-height: 96px;
}""",
    "profile-tab-css",
)
save(P, s)

print("all patches applied")
