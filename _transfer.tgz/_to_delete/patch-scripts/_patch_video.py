import sys, io

def load(path):
    return io.open(path, encoding="utf-8").read()

def save(path, text):
    io.open(path, "w", encoding="utf-8").write(text)

def sub(text, old, new, label):
    if text.count(old) != 1:
        print("FAIL(%s): found %d matches" % (label, text.count(old)))
        sys.exit(1)
    print("ok:", label)
    return text.replace(old, new, 1)


# ---------------------------------------------------------------- VideoIcons
P = "src/modules/video-analysis/components/VideoIcons.tsx"
s = load(P)
s = sub(
    s,
    """export const IconTrash = ({ className }: IconProps) => (""",
    """export const IconUndo = ({ className }: IconProps) => (
  <Svg className={className}>
    <path d="M9 8H5V4" />
    <path d="M5 8a8 8 0 1 1-1.2 6" />
  </Svg>
);

export const IconTrash = ({ className }: IconProps) => (""",
    "icon-undo",
)
save(P, s)


# ----------------------------------------------------------------- stylesheet
P = "src/modules/video-analysis/theme/videoAnalysis.css"
s = load(P)

# The tool rail is sticky at the top of the scroll area, so a tip above the
# button lands on the browser chrome. Below is always clear.
s = sub(
    s,
    """.video-tool-tip {
  position: absolute;
  bottom: calc(100% + 7px);
  left: 50%;
  transform: translateX(-50%) translateY(4px);""",
    """.video-tool-tip {
  position: absolute;
  top: calc(100% + 7px);
  left: 50%;
  transform: translateX(-50%) translateY(-4px);""",
    "tooltip-position",
)

s = sub(
    s,
    """.video-tool-btn:hover .video-tool-tip,
.video-tool-btn:focus-visible .video-tool-tip {
  opacity: 1;
  transform: translateX(-50%) translateY(0);
}""",
    """.video-tool-btn:hover .video-tool-tip,
.video-tool-btn:focus-visible .video-tool-tip {
  opacity: 1;
  transform: translateX(-50%) translateY(0);
}""",
    "tooltip-hover",
)

# The bin only renders while an object is being dragged, so it has to be
# visible for the whole drag. It was invisible until the cursor was already
# on top of it, which made it impossible to aim at.
s = sub(
    s,
    """  pointer-events: none;
  opacity: 0;
  transform: scale(0.92);
  transition: opacity 140ms ease, transform 140ms ease, border-color 140ms ease,
    color 140ms ease, box-shadow 140ms ease;
}""",
    """  pointer-events: none;
  opacity: 0.78;
  transform: scale(0.96);
  transition: opacity 140ms ease, transform 140ms ease, border-color 140ms ease,
    color 140ms ease, box-shadow 140ms ease;
}""",
    "trash-visible",
)

s = sub(
    s,
    """.video-trash-target.is-active {
  opacity: 0.96;
  transform: scale(1);""",
    """.video-trash-target.is-active {
  opacity: 1;
  transform: scale(1.06);""",
    "trash-active",
)

s = sub(
    s,
    """.video-trash-target svg {
  width: 16px;
  height: 16px;
}""",
    """.video-trash-target svg {
  width: 30px;
  height: 30px;
}""",
    "trash-icon-size",
)
save(P, s)


# -------------------------------------------------------------- VideoWorkspace
P = "src/modules/video-analysis/VideoWorkspace.tsx"
s = load(P)

# Clear now always means clear everything on this side. Deleting one object is
# what the bin target and the Delete key are for, and Undo sits next to it.
s = sub(
    s,
    """  const clearDrawingLabel = activeDrawing.selectedObjectId
    ? "Clear selected"
    : "Clear drawings on this side";
  const clearDrawingTooltip = clearDrawingLabel;
  const canClearDrawings = activeDrawing.objects.length > 0;

  const clearActiveDrawing = useCallback(() => {
    if (activeDrawing.selectedObjectId) {
      activeDrawing.deleteSelected();
      return;
    }
    if (!activeDrawing.objects.length) {
      return;
    }
    const message = `Clear ${activeDrawing.objects.length} drawings on this side? This can be undone.`;
    if (!window.confirm(message)) {
      return;
    }
    activeDrawing.clearAll();
  }, [activeDrawing]);""",
    """  const canClearDrawings = activeDrawing.objects.length > 0;

  const clearActiveDrawing = useCallback(() => {
    if (!activeDrawing.objects.length) {
      return;
    }
    activeDrawing.clearAll();
  }, [activeDrawing]);""",
    "clear-behaviour",
)

s = sub(
    s,
    """            canClearDrawings={canClearDrawings}
            clearDrawingLabel={clearDrawingLabel}
            clearDrawingTooltip={clearDrawingTooltip}""",
    """            canClearDrawings={canClearDrawings}
            onUndo={activeDrawing.undo}
            canUndo={activeDrawing.canUndo}""",
    "toolbar-props",
)
save(P, s)

print("all patches applied")
