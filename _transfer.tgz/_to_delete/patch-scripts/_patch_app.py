import sys, io

PATH = "src/App.tsx"
src = io.open(PATH, encoding="utf-8").read()
orig = src

def sub(old, new, label):
    global src
    if src.count(old) != 1:
        print("FAIL(%s): found %d matches" % (label, src.count(old)))
        sys.exit(1)
    src = src.replace(old, new, 1)
    print("ok:", label)


# The four-value save state was write-only apart from "saving", which is the
# only value anything read. A boolean says the same thing.
sub(
    """  const [lessonNoteSaveState, setLessonNoteSaveState] = useState<"idle" | "saving" | "saved" | "error">("idle");""",
    """  const [lessonNoteBusy, setLessonNoteBusy] = useState(false);""",
    "state",
)

sub(
    """  async function saveLessonNoteForClient(
    client: Pick<Person, "id" | "name"> | null | undefined,
    text: string,
    source: LessonNoteSource = "typed",
  ) {
    const cleanBody = text.trim();
    if (!client || !cleanBody) return;
    setLessonNoteSaveState("saving");
    try {""",
    """  // Returns whether the note actually reached the server. The note panel keeps
  // the coach's text in the box until this says the save landed.
  async function saveLessonNoteForClient(
    client: Pick<Person, "id" | "name"> | null | undefined,
    text: string,
    source: LessonNoteSource = "typed",
  ): Promise<boolean> {
    const cleanBody = text.trim();
    if (!client || !cleanBody) return false;
    setLessonNoteBusy(true);
    try {""",
    "save-signature",
)

sub(
    """      if (Array.isArray(data.notes)) setLessonNotes(cleanLessonNotes(data.notes));
      setLessonNoteSaveState("saved");
      setToast({ message: "Lesson note saved." });
      window.setTimeout(() => setLessonNoteSaveState("idle"), 1400);
    } catch (error) {
      setLessonNoteSaveState("error");
      setToast({ message: error instanceof Error ? error.message : "Could not save lesson note." });
    }
  }""",
    """      if (Array.isArray(data.notes)) setLessonNotes(cleanLessonNotes(data.notes));
      setToast({ message: "Lesson note saved." });
      return true;
    } catch (error) {
      setToast({ message: error instanceof Error ? error.message : "Could not save lesson note." });
      return false;
    } finally {
      setLessonNoteBusy(false);
    }
  }""",
    "save-body",
)

sub(
    """  async function deleteLessonNote(noteId: string) {
    if (!noteId) return;
    setLessonNoteSaveState("saving");
    try {""",
    """  async function deleteLessonNote(noteId: string) {
    if (!noteId) return;
    setLessonNoteBusy(true);
    try {""",
    "delete-signature",
)

sub(
    """      if (Array.isArray(data.notes)) setLessonNotes(cleanLessonNotes(data.notes));
      setLessonNoteSaveState("saved");
      setToast({ message: "Lesson note deleted." });
      window.setTimeout(() => setLessonNoteSaveState("idle"), 1400);
    } catch (error) {
      setLessonNoteSaveState("error");
      setToast({ message: error instanceof Error ? error.message : "Could not delete lesson note." });
    }
  }""",
    """      if (Array.isArray(data.notes)) setLessonNotes(cleanLessonNotes(data.notes));
      setToast({ message: "Lesson note deleted." });
    } catch (error) {
      setToast({ message: error instanceof Error ? error.message : "Could not delete lesson note." });
    } finally {
      setLessonNoteBusy(false);
    }
  }""",
    "delete-body",
)

# Hand the promise back so the panel can wait for the result.
sub(
    """                                    onCommit={(text) => void saveLessonNoteForClient(notesWorkspaceClient, text, "voice")}""",
    """                                    onCommit={(text) => saveLessonNoteForClient(notesWorkspaceClient, text, "voice")}""",
    "oncommit",
)

sub(
    """                                          disabled={lessonNoteSaveState === "saving"}""",
    """                                          disabled={lessonNoteBusy}""",
    "delete-disabled",
)

io.open(PATH, "w", encoding="utf-8").write(src)
print("written, delta bytes:", len(src) - len(orig))
