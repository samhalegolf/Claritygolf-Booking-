import sys, io

def load(p):
    return io.open(p, encoding="utf-8").read()

def save(p, t):
    io.open(p, "w", encoding="utf-8").write(t)

def sub(text, old, new, label):
    if text.count(old) != 1:
        print("FAIL(%s): found %d matches" % (label, text.count(old)))
        sys.exit(1)
    print("ok:", label)
    return text.replace(old, new, 1)


P = "src/modules/video-analysis/VideoAnalysisPage.tsx"
s = load(P)
s = sub(
    s,
    """  onOpenCloudSettings?: () => void;
}""",
    """  onOpenCloudSettings?: () => void;
  onSaveNote?: (text: string) => boolean | void | Promise<boolean | void>;
}""",
    "page-props",
)
save(P, s)


P = "src/App.tsx"
s = load(P)
s = sub(
    s,
    """                onOpenCloudSettings={() => {
                  setActiveView("settings");
                  setSettingsTab("integrations");
                }}""",
    """                onSaveNote={(text) =>
                  saveLessonNoteForClient(
                    videoContext ? { id: videoContext.playerId, name: videoContext.playerName } : null,
                    text,
                    "voice",
                  )
                }
                onOpenCloudSettings={() => {
                  setActiveView("settings");
                  setSettingsTab("integrations");
                }}""",
    "app-onsavenote",
)
save(P, s)

print("all patches applied")
