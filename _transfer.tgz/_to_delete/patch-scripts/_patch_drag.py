import sys, io

def load(p):
    return io.open(p, encoding="utf-8").read()

def save(p, t):
    io.open(p, "w", encoding="utf-8").write(t)

def sub(text, old, new, label):
    if text.count(old) != 1:
        print("FAIL(%s): found %d matches" % (label, text.count(old)))
        sys.exit(1)
    print("ok:", label)
    return text.replace(old, new, 1)


P = "src/modules/video-analysis/hooks/useDrawing.ts"
s = load(P)

# draftObject only exists while drawing something new. Requiring it up front
# meant dragging an existing object bailed out on the very first move.
s = sub(
    s,
    """      const { width, height } = videoDimensions;
      if (!width || !height) return;
      if (!draftObject) return;
      if (!editMode) return;
      if (editMode === "create") {
        setDraftObject(DrawingEngine.updateDraftObject(draftObject, cursor, videoDimensions));
        return;
      }""",
    """      const { width, height } = videoDimensions;
      if (!width || !height) return;
      if (!editMode) return;
      if (editMode === "create") {
        if (!draftObject) return;
        setDraftObject(DrawingEngine.updateDraftObject(draftObject, cursor, videoDimensions));
        return;
      }""",
    "pointer-move-guard",
)

# Same problem on release, plus the block that was meant to catch this case sat
# below an early return that always fired, so it could never run.
s = sub(
    s,
    """      if (!videoDimensions.width || !videoDimensions.height) return;
      if (!draftObject) {
        setEditMode(null);
        setInteraction(null);
        return;
      }
      if (editMode === "create") {
        if (DrawingEngine.canFinishDraft(draftObject)) {
          commit([...objects, draftObject]);
          setDraftObject(null);
        } else {
          setDraftObject(null);
          setEditMode(null);
        }
        return;
      }
      if (editMode === "edit" && selectedObjectId) {
        if (!interaction?.hasMoved) {
          setDraftObject(null);
          setInteraction(null);
          setEditMode(null);
          return;
        }
        let nextObjects = objects;
        if (draftObject.id === selectedObjectId) {
          nextObjects = objects.map((entry) =>
            entry.id === selectedObjectId ? draftObject : entry
          );
        }
        commit(nextObjects);
        return;
      }
      if (selectedObjectId) {
        const base = objects.find((entry) => entry.id === selectedObjectId);
        if (base && interaction) {
          const moved = DrawingEngine.transformObject(
            base,
            interaction.handle,
            cursor,
            { x: interaction.startX, y: interaction.startY },
            videoDimensions
          );
          const nextObjects = objects.map((entry) =>
            entry.id === selectedObjectId ? moved : entry
          );
          commit(nextObjects);
          return;
        }
      }
      setDraftObject(null);
      setInteraction(null);
      setEditMode(null);""",
    """      if (!videoDimensions.width || !videoDimensions.height) return;
      if (editMode === "create") {
        if (draftObject && DrawingEngine.canFinishDraft(draftObject)) {
          commit([...objects, draftObject]);
          return;
        }
        setDraftObject(null);
        setInteraction(null);
        setEditMode(null);
        return;
      }
      // A press that never passed the drag threshold is a selection, not an edit.
      if (editMode === "edit" && selectedObjectId && interaction?.hasMoved) {
        const base = objects.find((entry) => entry.id === selectedObjectId);
        const moved =
          draftObject && draftObject.id === selectedObjectId
            ? draftObject
            : base
              ? DrawingEngine.transformObject(
                  base,
                  interaction.handle,
                  cursor,
                  { x: interaction.startX, y: interaction.startY },
                  videoDimensions
                )
              : null;
        if (moved) {
          commit(objects.map((entry) => (entry.id === selectedObjectId ? moved : entry)));
          return;
        }
      }
      setDraftObject(null);
      setInteraction(null);
      setEditMode(null);""",
    "pointer-up",
)
save(P, s)


P = "src/modules/video-analysis/components/VideoCanvas.tsx"
s = load(P)
s = sub(
    s,
    """  const allObjects = [...objects];
  if (draftObject) {
    allObjects.push(draftObject);
  }""",
    """  // While an existing object is dragged, draftObject is the edited copy and
  // carries the same id. Render only the copy, otherwise the original draws
  // underneath it and React sees two nodes sharing a key.
  const allObjects = draftObject
    ? [...objects.filter((entry) => entry.id !== draftObject.id), draftObject]
    : objects;""",
    "canvas-dedupe",
)
save(P, s)

print("all patches applied")
