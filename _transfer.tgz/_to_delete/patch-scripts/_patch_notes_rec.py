import sys, io

def load(p):
    return io.open(p, encoding="utf-8").read()

def save(p, t):
    io.open(p, "w", encoding="utf-8").write(t)

def sub(text, old, new, label):
    if text.count(old) != 1:
        print("FAIL(%s): found %d matches" % (label, text.count(old)))
        sys.exit(1)
    print("ok:", label)
    return text.replace(old, new, 1)


# ============================================================ VideoWorkspace
P = "src/modules/video-analysis/VideoWorkspace.tsx"
s = load(P)

# --- imports -----------------------------------------------------------------
s = sub(
    s,
    """import { Inspector } from "./components/Inspector";
""",
    "",
    "drop-inspector-import",
)

s = sub(
    s,
    """import { PlayerVideo } from "./models/Video";""",
    """import { ClarityVoiceTextPanel } from "../clarity-voice/ClarityVoiceTextPanel";
import {
  AnalysisViewRecorder,
  getPreferredRecordingMimeType,
  getRecordingFileName,
  type AnalysisRecorderFrame,
  type AnalysisRecording,
} from "./utils/analysisRecorder";
import { PlayerVideo } from "./models/Video";""",
    "add-imports",
)

# --- the mime-type and file-name helpers now live with the recorder ----------
s = sub(
    s,
    """const getPreferredRecordingMimeType = () => {
  if (typeof MediaRecorder === "undefined" || typeof MediaRecorder.isTypeSupported !== "function") {
    return "";
  }
  return (
    [
      "video/mp4;codecs=h264",
      "video/webm;codecs=vp9",
      "video/webm;codecs=vp8",
      "video/webm",
    ].find((mimeType) => MediaRecorder.isTypeSupported(mimeType)) || ""
  );
};

const getRecordingFileName = (side: ComparisonSide, mimeType: string) => {
  const extension = mimeType.includes("mp4") ? "mp4" : "webm";
  const timestamp = new Date()
    .toISOString()
    .replace(/[:.]/g, "-")
    .replace("T", "-")
    .replace("Z", "");
  return `live-recording-${side}-${timestamp}.${extension}`;
};

""",
    "",
    "drop-duplicated-helpers",
)

s = sub(
    s,
    """            getRecordingFileName(recordingSide, blob.type || blobType),""",
    """            getRecordingFileName(`live-recording-${recordingSide}`, blob.type || blobType),""",
    "live-recording-filename",
)

# --- props -------------------------------------------------------------------
s = sub(
    s,
    """  onOpenCloudSettings?: () => void;
}""",
    """  onOpenCloudSettings?: () => void;
  /** Return false to tell the note panel the save failed and keep the text. */
  onSaveNote?: (text: string) => boolean | void | Promise<boolean | void>;
}""",
    "props-interface",
)

s = sub(
    s,
    """  onOpenCloudSettings,
}: VideoWorkspaceProps) {""",
    """  onOpenCloudSettings,
  onSaveNote,
}: VideoWorkspaceProps) {""",
    "props-destructure",
)

s = sub(
    s,
    """type RecordingStatus = "ready" | "recording" | "processing" | "error";""",
    """type RecordingStatus = "ready" | "recording" | "processing" | "error";
type ScreenRecordingStatus = "idle" | "recording" | "saving" | "error";""",
    "screen-recording-type",
)

# --- state and the live frame source the recorder reads ----------------------
s = sub(
    s,
    """  const canClearDrawings = activeDrawing.objects.length > 0;""",
    """  const canClearDrawings = activeDrawing.objects.length > 0;

  const analysisRecorderRef = useRef<AnalysisViewRecorder | null>(null);
  const [screenRecordingStatus, setScreenRecordingStatus] = useState<ScreenRecordingStatus>("idle");
  const [screenRecordingMessage, setScreenRecordingMessage] = useState("");
  // The recorder reads this on every frame, so it always draws the current
  // video and drawings without needing to be restarted when they change.
  const recorderFrameRef = useRef<AnalysisRecorderFrame>({
    video: null,
    objects: [],
    overlay: { width: 1, height: 1 },
  });
  recorderFrameRef.current = {
    video: effectiveActiveSide === "left" ? leftVideoRef.current : rightVideoRef.current,
    objects: activeDrawing.objects,
    overlay: effectiveActiveSide === "left" ? leftOverlayDimensions : rightOverlayDimensions,
  };""",
    "recorder-state",
)

# --- handlers ----------------------------------------------------------------
s = sub(
    s,
    """  const renderVideoCard = (
    side: ComparisonSide,""",
    """  // The recording is always saved as a brand new library item. The source
  // video it was recorded over is never written to.
  const saveScreenRecording = useCallback(
    async (recording: AnalysisRecording) => {
      const side = effectiveActiveSide;
      const sourceVideo = side === "left" ? playerVideoLeft : playerVideoRight;
      const createdAt = new Date().toISOString();
      const title = sourceVideo?.title ? `${sourceVideo.title} - commentary` : "Analysis commentary";
      const item = await savedVideoStore.saveItem({
        playerId: resolvedPlayerId,
        lessonId,
        title,
        sourceSide: side,
        sourceVideo: {
          id: `analysis-recording-${createId()}`,
          playerId: resolvedPlayerId,
          lessonId,
          sourceUrl: "",
          title: getRecordingFileName("analysis-recording", recording.mimeType),
          createdAt,
          duration: recording.durationMs / 1000,
          width: recording.width,
          height: recording.height,
        },
        sourceBlob: recording.blob,
        analysisSnapshot: analysisStore.analysis as VideoAnalysis,
        workspaceSnapshot: buildWorkspaceState(),
        thumbnailDataUrl: captureSideThumbnail(side),
      });
      onSavedVideoLibraryChange?.();
      setScreenRecordingStatus("idle");
      setScreenRecordingMessage(`Saved "${item.title || title}" as a new video.`);
    },
    [
      analysisStore.analysis,
      buildWorkspaceState,
      captureSideThumbnail,
      effectiveActiveSide,
      lessonId,
      onSavedVideoLibraryChange,
      playerVideoLeft,
      playerVideoRight,
      resolvedPlayerId,
      savedVideoStore,
    ]
  );

  const startScreenRecording = useCallback(async () => {
    if (analysisRecorderRef.current) return;
    const recorder = new AnalysisViewRecorder(() => recorderFrameRef.current);
    try {
      await recorder.start();
      analysisRecorderRef.current = recorder;
      setScreenRecordingStatus("recording");
      setScreenRecordingMessage("Recording this view with your commentary.");
    } catch (error) {
      setScreenRecordingStatus("error");
      setScreenRecordingMessage(
        error instanceof Error ? error.message : "Could not start recording."
      );
    }
  }, []);

  const stopScreenRecording = useCallback(async () => {
    const recorder = analysisRecorderRef.current;
    if (!recorder) return;
    setScreenRecordingStatus("saving");
    setScreenRecordingMessage("Saving recording...");
    try {
      const recording = await recorder.stop();
      analysisRecorderRef.current = null;
      await saveScreenRecording(recording);
    } catch (error) {
      analysisRecorderRef.current = null;
      setScreenRecordingStatus("error");
      setScreenRecordingMessage(
        error instanceof Error ? error.message : "Could not save the recording."
      );
    }
  }, [saveScreenRecording]);

  useEffect(
    () => () => {
      analysisRecorderRef.current?.cancel();
      analysisRecorderRef.current = null;
    },
    []
  );

  const handleWorkspaceNoteCommit = useCallback(
    async (text: string) => {
      if (!onSaveNote) return false;
      return (await onSaveNote(text)) !== false;
    },
    [onSaveNote]
  );

  const renderVideoCard = (
    side: ComparisonSide,""",
    "handlers",
)

# --- record button -----------------------------------------------------------
s = sub(
    s,
    """            <span className={`analysis-save-status is-${saveStatus}`} role="status">
              {saveMessage}
            </span>
          </div>""",
    """            <span className={`analysis-save-status is-${saveStatus}`} role="status">
              {saveMessage}
            </span>
          </div>
          <div className="analysis-record-controls" aria-label="Screen recording">
            <button
              type="button"
              className={`upload-button video-record-button${
                screenRecordingStatus === "recording" ? " is-recording" : ""
              }`}
              onClick={() =>
                screenRecordingStatus === "recording"
                  ? void stopScreenRecording()
                  : void startScreenRecording()
              }
              disabled={screenRecordingStatus === "saving"}
            >
              <IconRecord />
              {screenRecordingStatus === "recording"
                ? "Stop recording"
                : screenRecordingStatus === "saving"
                  ? "Saving..."
                  : "Screen record"}
            </button>
            {screenRecordingMessage ? (
              <span className={`analysis-record-status is-${screenRecordingStatus}`} role="status">
                {screenRecordingMessage}
              </span>
            ) : null}
          </div>""",
    "record-button",
)

# --- note panel under the videos ---------------------------------------------
s = sub(
    s,
    """          ) : (
            renderVideoCard("left", leftMetadataReady, leftOverlayDimensions, setLeftOverlayDimensions)
          )}
        </div>
      ) : null}""",
    """          ) : (
            renderVideoCard("left", leftMetadataReady, leftOverlayDimensions, setLeftOverlayDimensions)
          )}
        </div>
      ) : null}

      {workspaceHasVideo && onSaveNote ? (
        <section className="video-note-panel" aria-label="Lesson note">
          <h2>Lesson note</h2>
          <ClarityVoiceTextPanel
            fieldLabel="Lesson note"
            placeholder="Type or dictate a note about this swing."
            onCommit={handleWorkspaceNoteCommit}
          />
        </section>
      ) : null}""",
    "note-panel",
)

# --- drop the debug readout ---------------------------------------------------
s = sub(
    s,
    """      {workspaceHasVideo ? (
      <Inspector
        selectedTool={activeDrawing.selectedTool}
        selectedObject={currentDrawingObject}
        canUndo={activeDrawing.canUndo}
        canRedo={activeDrawing.canRedo}
        currentObjects={activeDrawing.objects.length}
      />
      ) : null}
""",
    "",
    "drop-inspector-jsx",
)
save(P, s)


# ================================================================ stylesheet
P = "src/modules/video-analysis/theme/videoAnalysis.css"
s = load(P)
s = sub(
    s,
    """.inspector {
  margin-top: 10px;
  border: 1px solid rgba(148, 169, 222, 0.25);
  border-radius: 12px;
  background: #0f1830;
  padding: 10px;
  color: #cbd7ff;
  display: grid;
  gap: 6px;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  font-size: 12px;
}""",
    """.analysis-record-controls {
  display: inline-flex;
  gap: 8px;
  align-items: center;
  flex-wrap: wrap;
}

.video-record-button {
  display: inline-flex;
  align-items: center;
  gap: 7px;
}

.video-record-button svg {
  width: 15px;
  height: 15px;
}

.video-record-button.is-recording {
  border-color: rgba(255, 107, 138, 0.62);
  color: #ffd8e1;
  background: rgba(120, 26, 46, 0.5);
}

.analysis-record-status {
  max-width: 220px;
  color: var(--va-muted, #a3adc2);
  font-size: 11px;
  line-height: 1.25;
}

.analysis-record-status.is-recording {
  color: rgba(255, 174, 194, 0.96);
}

.analysis-record-status.is-error {
  color: var(--va-danger, #ff6b8a);
}

.video-note-panel {
  margin-top: 14px;
  border: 1px solid var(--va-border, rgba(148, 169, 222, 0.22));
  border-radius: var(--va-radius-md, 13px);
  background: rgba(13, 18, 32, 0.82);
  padding: 12px 14px;
  display: grid;
  gap: 10px;
}

.video-note-panel h2 {
  margin: 0;
  font-size: 13px;
  letter-spacing: 0.02em;
  color: var(--va-text, #e9f0ff);
}

/* The note panel borrows the shared Clarity Voice panel, which is styled for
   light surfaces. Pull it onto the dark analysis theme. */
.video-note-panel .clarityVoiceTextOutput,
.video-note-panel .clarityVoiceInterim {
  color: var(--va-muted, #a3adc2);
}

.video-note-panel .clarityVoiceTextOutput textarea {
  background: rgba(6, 10, 20, 0.72);
  border-color: var(--va-border, rgba(148, 169, 222, 0.22));
  color: var(--va-text, #e9f0ff);
}

.video-note-panel .clarityVoiceMicButton {
  background: rgba(6, 10, 20, 0.72);
  border-color: var(--va-border, rgba(148, 169, 222, 0.22));
  color: var(--va-text, #e9f0ff);
}""",
    "css-swap",
)
save(P, s)

print("all patches applied")
