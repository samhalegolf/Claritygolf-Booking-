import sys, io

P = "src/App.tsx"
s = io.open(P, encoding="utf-8").read()

def sub(text, old, new, label):
    if text.count(old) != 1:
        print("FAIL(%s): found %d matches" % (label, text.count(old)))
        sys.exit(1)
    print("ok:", label)
    return text.replace(old, new, 1)


# --- create the client on demand, then hang the note or video off it ---------
s = sub(
    s,
    """  function openPlayerProfileVideos(client: Pick<Person, "id" | "name">) {""",
    """  // A booking that was never linked to a client still needs somewhere to hang a
  // note or a video. Create the client from the booking's own details and the
  // existing rule (note or video = player profile) promotes them from there.
  async function ensureClientForSelectedBooking(): Promise<Person | null> {
    if (selectedPerson) return selectedPerson;
    if (!selected || selected.kind !== "appointment") return null;
    const name = safeText(selected.client || selected.title).trim();
    const email = safeText(selected.email).trim();
    const phone = safeText(selected.phone).trim();
    if (!name && !email) {
      setToast({ message: "This booking needs a name or email before a note can be saved." });
      return null;
    }
    try {
      const response = await fetch("/api/people", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          person: { name, email, phone, notes: "", caddyProfileUrl: "" },
        }),
      });
      if (response.status === 401) {
        setAuthStatus("guest");
        throw new Error("Admin login required");
      }
      if (!response.ok) {
        throw new Error(await readApiFailure(response, "Could not add this booking to clients."));
      }
      const result = (await response.json()) as PeopleUpdateResult;
      if (Array.isArray(result.people)) setPeople(cleanPeople(result.people));
      if (!result.person?.id) return null;
      setToast({ message: `${result.person.name || "Client"} added to clients.` });
      return result.person;
    } catch (error) {
      setToast({
        message: error instanceof Error ? error.message : "Could not add this booking to clients.",
      });
      return null;
    }
  }

  async function saveSelectedBookingNote(text: string) {
    const client = await ensureClientForSelectedBooking();
    if (!client) return false;
    return saveLessonNoteForClient(client, text, "voice");
  }

  async function startSelectedBookingRecording() {
    const client = await ensureClientForSelectedBooking();
    if (!client) return;
    startVideoRecordingForClient(client);
  }

  function openPlayerProfileVideos(client: Pick<Person, "id" | "name">) {""",
    "ensure-client",
)


# --- the Profile tab now shows on every appointment -------------------------
s = sub(
    s,
    """      {selected.kind === "appointment" && selectedPerson && (
        <details className="booking-records-tab booking-profile-tab">
          <summary className="booking-records-summary">
            <User size={16} />
            <span>Profile</span>
            <em>{selectedPerson.name}</em>
          </summary>
          <div className="booking-records-body">
            <div className="booking-profile-actions">
              <button
                className="outline-button"
                onClick={() => startVideoRecordingForClient(selectedPerson)}
                type="button"
              >
                <Video size={16} />
                New recording
              </button>
              <button
                className="outline-button"
                onClick={() => openPlayerProfileVideos(selectedPerson)}
                type="button"
              >
                <User size={16} />
                Player profile
              </button>
            </div>
            <Suspense fallback={<div className="module-loading">Loading notes…</div>}>
              <ClarityVoiceTextPanel
                fieldLabel="Lesson note"
                placeholder="Type or dictate a note for this lesson."
                onCommit={(text) => saveLessonNoteForClient(selectedPerson, text, "voice")}
              />
            </Suspense>
          </div>
        </details>
      )}""",
    """      {selected.kind === "appointment" && (
        <details className="booking-records-tab booking-profile-tab">
          <summary className="booking-records-summary">
            <User size={16} />
            <span>Profile</span>
            <em>
              {selectedPerson
                ? selectedPerson.name
                : selected.client || selected.title || "Not a client yet"}
            </em>
          </summary>
          <div className="booking-records-body">
            <div className="booking-profile-actions">
              <button
                className="outline-button"
                onClick={() => void startSelectedBookingRecording()}
                type="button"
              >
                <Video size={16} />
                New recording
              </button>
              {selectedPerson ? (
                <button
                  className="outline-button"
                  onClick={() => openPlayerProfileVideos(selectedPerson)}
                  type="button"
                >
                  <User size={16} />
                  Player profile
                </button>
              ) : null}
            </div>
            {selectedPerson ? null : (
              <p className="booking-profile-hint">
                Saving a note or a recording adds this booking to clients and gives them a
                player profile.
              </p>
            )}
            <Suspense fallback={<div className="module-loading">Loading notes…</div>}>
              <ClarityVoiceTextPanel
                fieldLabel="Lesson note"
                placeholder="Type or dictate a note for this lesson."
                onCommit={(text) => saveSelectedBookingNote(text)}
              />
            </Suspense>
          </div>
        </details>
      )}""",
    "profile-tab-open",
)

io.open(P, "w", encoding="utf-8").write(s)


P = "src/styles.css"
s = io.open(P, encoding="utf-8").read()
s = sub(
    s,
    """.booking-profile-actions {""",
    """.booking-profile-hint {
  margin: 0;
  color: var(--muted);
  font-size: 12px;
  line-height: 1.45;
}

.booking-profile-actions {""",
    "hint-css",
)
io.open(P, "w", encoding="utf-8").write(s)

print("all patches applied")
