import sys, io

P = "src/modules/video-analysis/hooks/useDrawing.ts"
s = io.open(P, encoding="utf-8").read()

def sub(text, old, new, label):
    if text.count(old) != 1:
        print("FAIL(%s): found %d matches" % (label, text.count(old)))
        sys.exit(1)
    print("ok:", label)
    return text.replace(old, new, 1)

s = sub(
    s,
    """      if (editMode === "create") {
        if (draftObject && DrawingEngine.canFinishDraft(draftObject)) {
          commit([...objects, draftObject]);
          return;
        }""",
    """      if (editMode === "create") {
        if (draftObject && DrawingEngine.canFinishDraft(draftObject)) {
          commit([...objects, draftObject]);
          // Drop back to select and keep the new shape selected, so it can be
          // dragged straight away instead of the next press drawing another one.
          setSelectedObjectId(draftObject.id);
          setSelectedTool("select");
          return;
        }""",
    "auto-select",
)

io.open(P, "w", encoding="utf-8").write(s)
print("done")
