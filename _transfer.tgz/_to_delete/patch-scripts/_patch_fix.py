import sys, io

P = "src/modules/video-analysis/VideoWorkspace.tsx"
s = io.open(P, encoding="utf-8").read()

def sub(text, old, new, label):
    if text.count(old) != 1:
        print("FAIL(%s): found %d matches" % (label, text.count(old)))
        sys.exit(1)
    print("ok:", label)
    return text.replace(old, new, 1)

s = sub(
    s,
    """      const side = effectiveActiveSide;
      const sourceVideo = side === "left" ? playerVideoLeft : playerVideoRight;
      const createdAt = new Date().toISOString();
      const title = sourceVideo?.title ? `${sourceVideo.title} - commentary` : "Analysis commentary";
      const item = await savedVideoStore.saveItem({""",
    """      if (!savedVideoStore) {
        throw new Error("Device video storage is unavailable in this browser.");
      }
      const side = effectiveActiveSide;
      const analysisStore = side === "left" ? leftStore : rightStore;
      const sourceVideo = side === "left" ? playerVideoLeft : playerVideoRight;
      const createdAt = new Date().toISOString();
      const title = sourceVideo?.title ? `${sourceVideo.title} - commentary` : "Analysis commentary";
      const item = await savedVideoStore.saveItem({""",
    "guard-and-store",
)

s = sub(
    s,
    """    [
      analysisStore.analysis,
      buildWorkspaceState,
      captureSideThumbnail,
      effectiveActiveSide,
      lessonId,
      onSavedVideoLibraryChange,
      playerVideoLeft,
      playerVideoRight,
      resolvedPlayerId,
      savedVideoStore,
    ]""",
    """    [
      buildWorkspaceState,
      captureSideThumbnail,
      effectiveActiveSide,
      leftStore,
      lessonId,
      onSavedVideoLibraryChange,
      playerVideoLeft,
      playerVideoRight,
      resolvedPlayerId,
      rightStore,
      savedVideoStore,
    ]""",
    "deps",
)

io.open(P, "w", encoding="utf-8").write(s)
print("done")
