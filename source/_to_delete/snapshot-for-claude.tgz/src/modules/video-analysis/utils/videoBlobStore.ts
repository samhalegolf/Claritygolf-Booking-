import { PlayerVideo } from "../models/Video";
import {
  VIDEO_ANALYSIS_DB_STORES,
  isIndexedDbFactoryAvailable,
  openVideoAnalysisDatabase,
} from "./videoAnalysisDatabase";

// On-device video persistence.
//
// Video files are far too large for localStorage (~5MB, string-only), so the
// raw bytes live in IndexedDB, which stores Blobs natively and scales to the
// browser's disk quota. This keeps videos fully on the machine — nothing is
// uploaded to a backend. The interface is intentionally async and minimal so a
// future cloud-backed implementation (e.g. Google Drive) can satisfy the same
// contract without changing the workspace internals.

const STORE_NAME = VIDEO_ANALYSIS_DB_STORES.transientVideos;

export interface StoredVideo {
  video: PlayerVideo;
  blob: Blob;
}

export interface StoredVideoRecord extends StoredVideo {
  slotKey: string;
}

export interface VideoBlobStore {
  putVideo(slotKey: string, video: PlayerVideo, blob: Blob): Promise<void>;
  getVideo(slotKey: string): Promise<StoredVideo | null>;
  removeVideo(slotKey: string): Promise<void>;
  // Lightweight metadata for every stored video (no blob), used to derive which
  // players have footage and to feed recent-activity views.
  listVideoMeta(): Promise<PlayerVideo[]>;
  // Recovery records include the transient slot key so legacy slot-only videos
  // can be deliberately migrated into the saved-video library without deleting
  // the recovery copy first.
  listVideoRecords(): Promise<StoredVideoRecord[]>;
}

export const buildVideoSlotKey = (
  playerId: string,
  side: string,
  lessonId?: string
) => `${playerId}.${lessonId ?? "default"}.${side}`;

const openDb = (): Promise<IDBDatabase> =>
  openVideoAnalysisDatabase("transient-video-store.open");

const runRequest = <T>(
  mode: IDBTransactionMode,
  operate: (store: IDBObjectStore) => IDBRequest
): Promise<T> =>
  openDb().then(
    (db) =>
      new Promise<T>((resolve, reject) => {
        const tx = db.transaction(STORE_NAME, mode);
        const store = tx.objectStore(STORE_NAME);
        const request = operate(store);
        request.onsuccess = () => resolve(request.result as T);
        request.onerror = () => reject(request.error);
        tx.onerror = () => reject(tx.error);
        tx.oncomplete = () => db.close();
      })
  );

/**
 * Creates the IndexedDB-backed video store, or returns null when IndexedDB is
 * unavailable (e.g. private-mode restrictions or non-browser environments). A
 * null store degrades gracefully: videos simply won't persist across reloads.
 */
export const createIndexedDbVideoStore = (): VideoBlobStore | null => {
  if (!isIndexedDbFactoryAvailable()) return null;

  return {
    async putVideo(slotKey, video, blob) {
      await runRequest("readwrite", (store) =>
        store.put({ video, blob }, slotKey)
      );
    },
    async getVideo(slotKey) {
      const result = await runRequest<StoredVideo | undefined>(
        "readonly",
        (store) => store.get(slotKey)
      );
      if (!result || !(result.blob instanceof Blob) || !result.video) {
        return null;
      }
      return result;
    },
    async removeVideo(slotKey) {
      await runRequest("readwrite", (store) => store.delete(slotKey));
    },
    async listVideoMeta() {
      const records = await runRequest<StoredVideo[]>("readonly", (store) =>
        store.getAll()
      );
      return (records || [])
        .filter((record) => record && record.video)
        .map((record) => record.video);
    },
    async listVideoRecords() {
      return openDb().then(
        (db) =>
          new Promise<StoredVideoRecord[]>((resolve, reject) => {
            const tx = db.transaction(STORE_NAME, "readonly");
            const store = tx.objectStore(STORE_NAME);
            const request = store.openCursor();
            const records: StoredVideoRecord[] = [];

            request.onsuccess = () => {
              const cursor = request.result;
              if (!cursor) return;
              const value = cursor.value as StoredVideo | undefined;
              if (value?.video && value.blob instanceof Blob) {
                records.push({
                  ...value,
                  slotKey: String(cursor.key),
                });
              }
              cursor.continue();
            };
            request.onerror = () => reject(request.error);
            tx.onerror = () => reject(tx.error);
            tx.oncomplete = () => {
              db.close();
              resolve(records);
            };
          })
      );
    },
  };
};

/**
 * Asks the browser to keep on-device storage durable so it is not evicted
 * automatically when disk space runs low. Best-effort; resolves false when the
 * API is unavailable or the request is declined.
 */
export const requestPersistentStorage = async (): Promise<boolean> => {
  try {
    if (
      typeof navigator !== "undefined" &&
      navigator.storage &&
      typeof navigator.storage.persist === "function"
    ) {
      return await navigator.storage.persist();
    }
  } catch {
    // Ignore; persistence is a best-effort optimization.
  }
  return false;
};
