-- Run this once in the Supabase project used by Clarity Booking before
-- deploying the Supabase-backed booking functions.

create table if not exists public.settings (
  key text primary key,
  value text not null,
  updated_at timestamptz not null default now()
);

create table if not exists public.calendar_items (
  id text primary key,
  account_id text,
  kind text not null,
  week integer not null default 0,
  day integer not null,
  start integer not null,
  duration integer not null,
  coach_id text,
  location_id text,
  service_id text,
  client text,
  title text not null,
  phone text,
  email text,
  note text,
  coach jsonb,
  location jsonb,
  custom_group jsonb,
  status text not null default 'booked'
    check (status in ('booked', 'completed', 'cancelled', 'no_show')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_calendar_items_slot
  on public.calendar_items (week, day, start);

create index if not exists idx_calendar_items_account_slot
  on public.calendar_items (account_id, week, day, start);

create table if not exists public.people (
  id text primary key,
  account_id text,
  name text not null,
  email text,
  phone text,
  notes text,
  source text,
  caddy_profile_id text,
  caddy_profile_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Email is a contact method, not an identity: parents book for several children
-- on one address, clubs book for their players, couples share an inbox. So there
-- is deliberately NO unique index on email — only a lookup index. Same-person
-- merging is done in the application (compatiblePersonMatch), on a matching name
-- plus a compatible phone or email, never on an email alone.
drop index if exists public.idx_people_email_unique;
drop index if exists public.idx_people_account_email_unique;

create index if not exists idx_people_account_email_lookup
  on public.people (account_id, lower(email))
  where email is not null and btrim(email) <> '';

create index if not exists idx_people_email_lookup
  on public.people (lower(email))
  where email is not null and btrim(email) <> '';

create index if not exists idx_people_name_phone_lookup
  on public.people (lower(name), phone)
  where phone is not null and phone <> '';

create index if not exists idx_people_account_name_lookup
  on public.people (account_id, lower(name), lower(email), id);

create table if not exists public.admin_users (
  id text primary key,
  email text unique not null,
  password_hash text not null,
  password_salt text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.admin_sessions (
  id text primary key,
  token_hash text unique not null,
  user_id text not null,
  expires_at timestamptz not null,
  created_at timestamptz not null default now()
);

create table if not exists public.admin_password_resets (
  id text primary key,
  token_hash text unique not null,
  user_id text not null,
  expires_at timestamptz not null,
  used_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.notification_history (
  id text primary key,
  person_key text,
  calendar_item_id text,
  recipient text not null,
  subject text not null,
  kind text not null,
  status text not null,
  provider text,
  provider_id text,
  error text,
  created_at timestamptz not null default now()
);

create index if not exists idx_notification_history_person
  on public.notification_history (person_key, created_at desc);

create index if not exists idx_notification_history_item
  on public.notification_history (calendar_item_id, created_at desc);

create index if not exists idx_notification_history_provider
  on public.notification_history (provider_id)
  where provider_id is not null and provider_id <> '';

create table if not exists public.notification_webhook_events (
  id text primary key,
  provider_id text,
  event_type text not null,
  payload text,
  received_at timestamptz not null default now()
);

create table if not exists public.google_provider_connections (
  id text primary key,
  account_id text not null,
  provider text not null default 'google',
  provider_user_id text,
  provider_email text,
  encrypted_refresh_token_json text not null,
  encrypted_refresh_token_version integer not null default 1,
  granted_scopes_json text not null default '[]',
  calendar_enabled boolean not null default false,
  drive_enabled boolean not null default false,
  connection_status text not null default 'connected',
  connected_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  last_token_refresh_at timestamptz,
  last_successful_use_at timestamptz,
  revoked_at timestamptz,
  last_error_code text,
  last_error_at timestamptz,
  constraint google_provider_connections_provider_check check (provider = 'google'),
  constraint google_provider_connections_status_check check (
    connection_status in ('connected', 'reconnect_required', 'disconnected', 'revoked', 'error')
  )
);

create unique index if not exists idx_google_provider_connections_account_provider
  on public.google_provider_connections (account_id, provider);

create index if not exists idx_google_provider_connections_status
  on public.google_provider_connections (connection_status);

alter table public.settings enable row level security;
alter table public.calendar_items enable row level security;
alter table public.people enable row level security;
alter table public.admin_users enable row level security;
alter table public.admin_sessions enable row level security;
alter table public.admin_password_resets enable row level security;
alter table public.notification_history enable row level security;
alter table public.notification_webhook_events enable row level security;
alter table public.google_provider_connections enable row level security;
